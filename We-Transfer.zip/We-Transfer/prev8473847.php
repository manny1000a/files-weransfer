<html>

<head>
<meta charset="UTF-8">
  <title>Bestanden | </title>
  
<script src="http://code.jquery.com/jquery-3.2.1.min.js"></script>
 
  <link rel="icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAASFBMVEUAAAAJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrH////aXMaSAAAAFnRSTlMAIHDAgKAQkNBAsODwUHmoYIfqMIg83ZjUrQAAAAFiS0dEFwvWmI8AAAAHdElNRQfjAgUNJxNHuQA2AAAAsElEQVQ4y+WQWRICIQxEwxaQRVE09z+qDMssFBzA8n1l6J6mA8DvwbgQQrKlzqmicK5r6pjRcbPOC0kHevWrzx3KcOkR9uT79omPPPKzwfVuEE0OUez5EvKkp6YLUO2eMDRsBra39HYLapugNC0APV2ou7J26t+fQAOlh62zxaTdaHCboacpmnAYQpzp5GQ3oKA5HKoCK4OBVLZIK0OuUbTIlwkNNHND3N97vqeGP+ELXJsiW6N0qWcAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMDItMDVUMTI6Mzk6MTkrMDE6MDCj1f02AAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTAyLTA1VDEyOjM5OjE5KzAxOjAw0ohFigAAAABJRU5ErkJggg==" sizes="32x32" />
   <meta http-equiv="refresh" content="5;URL='contract_Xoom-offer-structure.pdf'" />  
</head>

<body style="font-family: arial;">
<center style="position: absolute; top: 50%; left: 50%; margin-top: -50px; margin-left: -50px; width: 100px; height: 100px;">

<img src="heroi/msload.svg" style="width: 50%;" >
<br><br>
<span style=" color: black; font-size: 15px; font-weight: 600; ">Loading</span>

<br>
 




</center>
 
</body>
</html>